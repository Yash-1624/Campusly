import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";
import "./HomePage.css";

function formatEventDate(date) {
    if (!date) return "Date to be announced";
    return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(new Date(date));
}

export default function HomePage() {
    const [events, setEvents] = useState([]);
    const [search, setSearch] = useState("");
    const [error, setError] = useState("");

    useEffect(() => {
        let active = true;
        api.get("/events")
            .then(({ data }) => { if (active) setEvents(Array.isArray(data.events) ? data.events : []); })
            .catch(() => { if (active) setError("Events are temporarily unavailable. Please check back soon."); });
        return () => { active = false; };
    }, []);

    const categories = useMemo(() => {
        const counts = new Map();
        events.forEach(({ category }) => {
            const name = category?.trim();
            if (name) counts.set(name, (counts.get(name) || 0) + 1);
        });
        return [...counts.entries()].slice(0, 4);
    }, [events]);

    const shownEvents = useMemo(() => {
        const query = search.trim().toLowerCase();
        return events.filter((event) => !query || [event.name, event.category, event.location, event.description].some((value) => value?.toLowerCase().includes(query))).slice(0, 3);
    }, [events, search]);

    return (
        <main className="home-page">
            <section className="home-hero">
                <div className="hero-noise" aria-hidden="true" />
                <div className="home-hero-inner">
                    <div className="hero-copy">
                        <div className="hero-kicker"><span className="kicker-dot" /> CAMPUS EVENTS, ALL IN ONE PLACE</div>
                        <h1>Where Campus Life<br /><span>Comes Alive.</span></h1>
                        <p>Discover events, find your community, and make more of every moment on campus.</p>
                        <form className="event-search" onSubmit={(event) => { event.preventDefault(); document.querySelector("#explore")?.scrollIntoView({ behavior: "smooth" }); }}>
                            <span className="search-icon" aria-hidden="true">⌕</span>
                            <input aria-label="Search events" placeholder="Search events, places, and more" value={search} onChange={(event) => setSearch(event.target.value)} />
                            <button type="submit">Explore <span aria-hidden="true">↗</span></button>
                        </form>
                        <div className="hero-footnote"><span className="avatar-stack" aria-hidden="true"><i>✦</i><i>◉</i><i>✳</i></span><span>A little something for every kind of curious.</span></div>
                    </div>
                    <div className="hero-art" aria-label="Discover, participate, celebrate"><div className="hero-brand-panel"><span className="hero-panel-kicker">YOUR CAMPUS, IN MOTION</span><strong>Discover.<br />Participate.<br /><em>Celebrate.</em></strong><span className="hero-panel-rule" /><span className="hero-panel-caption">COLLEGE EVENTS, ALL IN ONE PLACE</span></div></div>
                </div>
                <div className="hero-bottomline"><span>CURATED FOR YOUR CAMPUS</span><span>SCROLL TO DISCOVER <b>↓</b></span></div>
            </section>

            <section className="home-section explore-section" id="explore">
                <div className="section-heading">
                    <div><p className="eyebrow">FIND YOUR PEOPLE</p><h2>What’s happening<span className="heading-period">.</span></h2></div>
                    <Link className="text-link" to="/login?next=/student/events">See all events <span aria-hidden="true">↗</span></Link>
                </div>
                {error && <p className="home-error" role="status">{error}</p>}
                {shownEvents.length ? <div className="home-event-grid">
                    {shownEvents.map((event, index) => <Link className="home-event-card" key={event._id} to={`/login?next=${encodeURIComponent(`/student/events/${event._id}`)}`}>
                        <div className="event-art">
                            {event.imageUrl ? <img src={event.imageUrl} alt="" loading="lazy" /> : <><span className="event-art-shape" /><span className="event-art-mark">{index === 0 ? "✳" : index === 1 ? "✦" : "◒"}</span><span className="event-art-word">{event.category || "CAMPUS"}</span></>}
                            <span className="event-date-chip">{formatEventDate(event.date)}</span>
                        </div>
                        <div className="event-card-info"><div className="event-card-category">{event.category || "Campus event"}</div><h3>{event.name}</h3><p><span aria-hidden="true">⌖</span> {event.location || "Campus venue"}</p><div className="event-card-bottom"><span>Discover event</span><b aria-hidden="true">↗</b></div></div>
                    </Link>)}
                </div> : <div className="home-empty">{search ? "No events match that search yet." : "New events are on the way. Check back soon."}</div>}
            </section>

            <section className="home-proof-strip" aria-label="Campus event overview">
                <div><strong>{events.length}</strong><span>listed events</span></div>
                <div><strong>{categories.length}</strong><span>event categories</span></div>
                <div><strong>{events.filter((event) => Number(event.fee || 0) === 0).length}</strong><span>free to attend</span></div>
                <p>All numbers update from your campus event listings.</p>
            </section>

            <section className="category-strip" aria-label="Event categories">
                <div className="category-intro"><p className="eyebrow">FOLLOW YOUR CURIOSITY</p><h2>Pick a<br />starting point.</h2></div>
                <div className="category-list">{categories.length ? categories.map(([category, count], index) => <button type="button" key={category} onClick={() => { setSearch(category); document.querySelector("#explore")?.scrollIntoView({ behavior: "smooth" }); }} className={`category-item category-${index}`}><span className="category-symbol">{["✳", "◈", "✦", "◒"][index]}</span><span className="category-name">{category}</span><span className="category-count">{count} {count === 1 ? "event" : "events"}</span><span className="category-arrow" aria-hidden="true">↗</span></button>) : <p className="category-empty">Explore events as they’re added by your campus.</p>}</div>
            </section>

            <section className="home-manifesto" id="how-it-works">
                <div className="manifesto-index">01 / SHOW UP</div>
                <div className="manifesto-copy"><p className="eyebrow">MORE THAN A CALENDAR</p><h2>Your campus is full of<br /><em>almost-missed moments.</em></h2><p>Campusly brings them into one place. Find something that sparks your interest, save your spot, and see where the day takes you.</p><Link className="manifesto-link" to="/signup">Find your next thing <span aria-hidden="true">↗</span></Link></div>
                <div className="manifesto-visual" aria-hidden="true"><div className="manifesto-circle circle-large">SHOW<br />UP</div><div className="manifesto-circle circle-small">✦</div><div className="manifesto-label">MAKE IT<br />A CAMPUS<br />THING.</div></div>
            </section>

            <footer className="home-footer"><Link className="brand footer-brand" to="/" aria-label="Campusly home"><span>Campusly</span></Link><span>Good things happen when we get together.</span><div><Link to="/login">Log in</Link><Link to="/signup">Join your campus ↗</Link></div></footer>
        </main>
    );
}
