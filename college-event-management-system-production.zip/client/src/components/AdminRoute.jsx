import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import Loading from "./Loading";

export default function AdminRoute() {
    const { user, loading } = useAuth();

    if (loading) return <Loading />;

    if (!user) {
        return <Navigate to="/control-center" replace />;
    }

    if (user.role !== "admin") {
        return <Navigate to={user.role === "volunteer" ? "/volunteer/dashboard" : "/student"} replace />;
    }

    return <Outlet />;
}
