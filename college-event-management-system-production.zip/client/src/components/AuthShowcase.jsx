import "./AuthShowcase.css";

export default function AuthShowcase({ mode = "signup" }) {
    const isSignup = mode === "signup";

    return (
        <aside className="auth-showcase" aria-label="Campusly introduction">
            <div className="auth-showcase-copy">
                <p className="auth-showcase-kicker"><span /> CAMPUSLY · COLLEGE EVENTS</p>
                <h2>{isSignup ? <>Your next great<br /><em>campus story</em><br />starts here.</> : <>Find your next<br /><em>campus moment.</em></>}</h2>
                <p className="auth-showcase-description">
                    Discover your community, meet new people, and make every campus moment count.
                </p>
                <button className="auth-scroll-button" type="button" onClick={() => document.querySelector(".auth-page-student .form-card")?.scrollIntoView({ behavior: "smooth", block: "start" })}>
                    <span aria-hidden="true">↓</span> Continue to form
                </button>
            </div>

            <div className="auth-showcase-art" aria-hidden="true">
                <span className="auth-orbit auth-orbit-one" />
                <span className="auth-orbit auth-orbit-two" />
                <span className="auth-glow" />
                <div className="auth-platform"><span /></div>
                <div className="auth-calendar">
                    <div className="auth-calendar-rings"><i /><i /></div>
                    <div className="auth-calendar-head"><span className="auth-calendar-mark">✦</span><span className="auth-calendar-lines"><i /><i /></span></div>
                    <div className="auth-calendar-grid">{Array.from({ length: 9 }, (_, index) => <i key={index} />)}</div>
                    <span className="auth-calendar-orb" />
                </div>
                <span className="auth-floating-star star-one">✦</span>
                <span className="auth-floating-star star-two">✧</span>
                <span className="auth-floating-dot dot-one" />
            </div>
        </aside>
    );
}
