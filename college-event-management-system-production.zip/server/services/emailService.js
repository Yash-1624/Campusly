
const transporter = require("../config/mail");

// =====================================================
// EMAIL VERIFICATION OTP
// =====================================================
const sendOTPEmail = async (email, name, otp) => {
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: "Campusly - Email Verification OTP",
    text: `Hello ${name}, your email verification OTP is ${otp}. It expires in 10 minutes.`,
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.6;color:#172033">
        <h2>Email Verification</h2>
        <p>Hello ${name || "Student"},</p>
        <p>Use the following OTP to verify your email address:</p>
        <h1 style="letter-spacing:6px;color:#5145cd">${otp}</h1>
        <p>This OTP expires in 10 minutes.</p>
        <p>If you did not request this, you can ignore this email.</p>
      </div>
    `,
  });
};

// Compatibility with authController.js
const sendVerificationOTP = async (email, otp, name = "Student") => {
  return sendOTPEmail(email, name, otp);
};

// =====================================================
// PASSWORD RESET OTP
// =====================================================
const sendPasswordResetEmail = async (email, name, otp) => {
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: "Campusly - Password Reset OTP",
    text: `Hello ${name}, your password reset OTP is ${otp}. It expires in 10 minutes.`,
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.6;color:#172033">
        <h2>Password Reset</h2>
        <p>Hello ${name || "Student"},</p>
        <p>Your password reset OTP is:</p>
        <h1 style="letter-spacing:6px;color:#5145cd">${otp}</h1>
        <p>This OTP expires in 10 minutes.</p>
        <p>If you did not request a password reset, ignore this email.</p>
      </div>
    `,
  });
};

// Compatibility with authController.js
const sendPasswordResetOTP = async (email, otp, name = "Student") => {
  return sendPasswordResetEmail(email, name, otp);
};

// =====================================================
// REGISTRATION CONFIRMATION EMAIL WITH QR TICKET
// =====================================================
const sendRegistrationConfirmationEmail = async ({
  email,
  student,
  event,
  registration,
  payment,
  ticket,
}) => {
  const teamHtml =
    registration?.participation?.type === "Team"
      ? `
        <p><strong>Team:</strong> ${registration.participation.teamName || "-"}</p>
        <p><strong>Team Members:</strong> ${registration.participation.numberOfMembers || "-"}</p>
      `
      : "";

  const ticketHtml = ticket?.qrCode
    ? `
      <div style="margin-top:30px;padding:25px;border:2px solid #2857d8;border-radius:15px;text-align:center;background:#f8faff">
        <h2 style="color:#172033">Event Entry QR Ticket</h2>
        <p>Show this QR code at the event entrance.</p>
        <img src="cid:event-entry-qr" alt="Event Entry QR Code" width="280" height="280" style="display:block;margin:20px auto" />
        <p><strong>Ticket ID:</strong> ${ticket.ticketId || "-"}</p>
        <p><strong>College PID:</strong> ${ticket.collegePid || "-"}</p>
        <p><strong>Student:</strong> ${ticket.studentName || student?.fullName || "-"}</p>
        <p><strong>Event:</strong> ${ticket.eventName || event?.name || "-"}</p>
        <p style="color:#16733a;font-weight:bold">Entry Status: Not Entered</p>
      </div>
    `
    : `
      <div style="margin-top:25px;padding:15px;border:1px solid #f6c7c3;border-radius:8px;background:#fff0ef;color:#a51d14">
        QR ticket could not be generated. Please contact the event administrator.
      </div>
    `;

  const attachments = [];

  if (ticket?.qrCode) {
    const base64Image = ticket.qrCode.replace(
      /^data:image\/[a-zA-Z0-9.+-]+;base64,/,
      ""
    );

    attachments.push({
      filename: "event-entry-qr.png",
      content: Buffer.from(base64Image, "base64"),
      contentType: "image/png",
      cid: "event-entry-qr",
    });
  }

  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: `Campusly Registration Successful - ${event?.name || "College Event"}`,
    attachments,
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.6;max-width:700px;margin:auto;color:#172033">
        <h1>Registration Successful</h1>
        <p>Congratulations <strong>${student?.fullName || "Student"}</strong>!</p>

        <h2>Student Information</h2>
        <p><strong>Name:</strong> ${student?.fullName || "-"}</p>
        <p><strong>College PID:</strong> ${student?.collegePid || "-"}</p>
        <p><strong>College:</strong> ${student?.collegeName || "-"}</p>
        <p><strong>Year/Semester:</strong> ${student?.yearSemester || "-"}</p>
        <p><strong>Email:</strong> ${student?.email || email || "-"}</p>
        <p><strong>Mobile:</strong> ${student?.mobileNumber || "-"}</p>

        <h2>Event Information</h2>
        <p><strong>Event:</strong> ${event?.name || "-"}</p>
        <p><strong>Category:</strong> ${event?.category || "-"}</p>
        <p><strong>Date:</strong> ${event?.date ? new Date(event.date).toLocaleString() : "-"
      }</p>
        <p><strong>Location:</strong> ${event?.location || "-"}</p>

        <h2>Participation</h2>
        <p><strong>Type:</strong> ${registration?.participation?.type || "-"}</p>
        ${teamHtml}

        <h2>Registration & Payment</h2>
        <p><strong>Registration ID:</strong> ${registration?.registrationId || "-"}</p>
        <p><strong>Transaction ID:</strong> ${payment?.transactionId || "-"}</p>
        <p><strong>Payment Status:</strong> ${payment?.status || "-"}</p>
        <p><strong>Amount:</strong> ₹${payment?.amount ?? "-"}</p>

        ${ticketHtml}

        <p style="margin-top:30px;color:#657086;font-size:13px">
          Keep this email and QR ticket safe. Show the QR code at the event entrance.
        </p>
      </div>
    `,
  });
};


// =====================================================
// VOLUNTEER LOGIN CREDENTIALS
// =====================================================
const sendVolunteerCredentialsEmail = async ({ email, name, loginId, password, eventName }) => {
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: "Your Campusly Volunteer Login Credentials",
    text: `Hello ${name},\n\nYour volunteer account has been created.\nLogin page: ${process.env.CLIENT_URL || "http://localhost:5173"}/volunteer-access\nLogin ID: ${loginId}\nTemporary password: ${password}\nAssigned event: ${eventName}\n\nPlease sign in and change your password if password-change functionality is enabled. Do not share these credentials.`,
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.7;max-width:620px;margin:auto;color:#172033">
        <h2>Your Volunteer Account Is Ready</h2>
        <p>Hello <strong>${name}</strong>,</p>
        <p>The event administrator has created your volunteer account. Use these temporary credentials to sign in:</p>
        <div style="padding:18px;background:#f4f6fb;border-radius:10px">
          <p><strong>Login ID:</strong> ${loginId}</p>
          <p><strong>Temporary password:</strong> ${password}</p>
          <p><strong>Assigned event:</strong> ${eventName}</p>
        </div>
        <p><a href="${(process.env.CLIENT_URL || "http://localhost:5173").replace(/\/$/, "")}/volunteer-access" style="display:inline-block;padding:12px 20px;background:#2457d6;color:#fff;text-decoration:none;border-radius:7px">Open Volunteer Login</a></p>
        <p>Keep these credentials private. This temporary password should not be shared with anyone.</p>
        <p>Regards,<br/>Campusly Team</p>
      </div>
    `,
  });
};


// =====================================================
// INDIVIDUAL VOLUNTEER EVENT ALLOCATION EMAIL
// One message is sent for each event assigned to a volunteer.
// =====================================================
const sendVolunteerEventAllocationEmail = async ({ email, name, event }) => {
  const eventDate = event?.date ? new Date(event.date).toLocaleString() : "To be announced";
  const eventName = event?.name || "College Event";
  const eventDescription = event?.description || "Please contact the event administrator for additional instructions.";
  const loginUrl = `${(process.env.CLIENT_URL || "http://localhost:5173").replace(/\/$/, "")}/volunteer-access`;
  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: email,
    subject: `Volunteer Event Allocation - ${eventName}`,
    text: `Hello ${name},\n\nYou have been allocated as a volunteer for the following event.\nEvent: ${eventName}\nCategory: ${event?.category || "-"}\nDate and time: ${eventDate}\nLocation: ${event?.location || "To be announced"}\nDetails: ${eventDescription}\n\nSign in to the Volunteer Portal: ${loginUrl}\nPlease use the login credentials sent in your separate account-credentials email.`,
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.7;max-width:650px;margin:auto;color:#172033">
        <h2 style="color:#2457d6">Volunteer Event Allocation</h2>
        <p>Hello <strong>${name}</strong>,</p>
        <p>The administrator has allocated you to the following event as a volunteer.</p>
        <div style="padding:20px;background:#f4f6fb;border-radius:10px">
          <h3 style="margin-top:0">${eventName}</h3>
          <p><strong>Category:</strong> ${event?.category || "-"}</p>
          <p><strong>Date and time:</strong> ${eventDate}</p>
          <p><strong>Location:</strong> ${event?.location || "To be announced"}</p>
          <p><strong>Event details:</strong><br/>${eventDescription}</p>
          <p><strong>Event fee:</strong> ${event?.fee != null ? `₹${event.fee}` : "-"}</p>
        </div>
        <p>Use the credentials from your separate volunteer account email to access your dashboard and assigned event information.</p>
        <p><a href="${loginUrl}" style="display:inline-block;padding:12px 20px;background:#2457d6;color:#fff;text-decoration:none;border-radius:7px">Open Volunteer Portal</a></p>
        <p>Regards,<br/>Campusly Team</p>
      </div>
    `,
  });
};

module.exports = {
  sendOTPEmail,
  sendVerificationOTP,
  sendPasswordResetEmail,
  sendPasswordResetOTP,
  sendRegistrationConfirmationEmail,
  sendVolunteerCredentialsEmail,
  sendVolunteerEventAllocationEmail,
};
